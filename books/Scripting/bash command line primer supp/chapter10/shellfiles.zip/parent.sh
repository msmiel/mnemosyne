#check result of executing cmdarsh.sh

echo "first time:"
./cmdargs.sh pasta
echo "result = $?"

echo "second time:"
./cmdargs.sh
echo "result = $?"

echo "third time:"
cmdargs.sh 
echo "result = $?"	

