# make sure that you "cd" into the "names2" directory
for d in `ls ../names`
do
  echo "Creating directory $d" 
  mkdir $d
done 

